import React from 'react'

const MenuCard = () => {
    return (
        <div>
            
        </div>
    )
}

export default MenuCard;
