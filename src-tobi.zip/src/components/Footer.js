import React from 'react';

const Footer = () => {
    return (
        <>
            <footer className="footer text-center">
                <p className="footer-text">FoodBukka Ltd. | All rights reserved  |  2020. </p>
            </footer>
        </>
    );
}

export default Footer;
