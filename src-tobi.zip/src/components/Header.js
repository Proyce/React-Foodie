import React from 'react'

const Header = () => {
    return (
        <div>
            <>
                <header className="header">
                    
                </header>
            </>
        </div>
    )
}

export default Header
