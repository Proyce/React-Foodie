import React from "react";
import Navbar from "../components/Navbar";
import Header from "../components/Header";
import BukkaCards from "../components/BukkaCards";
import BukkaCarousel from "../components/BukkaCarousel";
import Footer from "../components/Footer";
import foodImg from "../images/foodbukka-2.jpg";
import foodChaw from "../images/food-chaw.jpg";
import riceImg from "../images/nigerian-egg-fried-rice.jpg";
import { MdLocationOn } from "react-icons/md";
import { FaMoneyBill } from "react-icons/fa";
import { IoMdRestaurant } from "react-icons/io";
import { FaRestroom } from "react-icons/fa";
import { FaPhoneSquare } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FcRating } from "react-icons/fc";
import { IoIosTime } from "react-icons/io";
import { FaCar } from "react-icons/fa";
import { FaChair } from "react-icons/fa";

const Bukkas = ({bukkaProfileData, slug}) => {
  console.log('page ', slug);
  const {
    businessname, price, phone, email, mapLink, reviews, rating, location, restaurantType, capacity, hoursWeekday, hoursSat, hoursSun, parking, restroom, details, menu,
  } = bukkaProfileData[sessionStorage.getItem('bukkaslug')];
  return (
    <>
      <Navbar />
      <Header />
      <main className="name">
        <section className="bukka-flex-container">
          <section className="left left-bukka mb-15">
            <h2 className="mt-50 ml-50 mb-25 center">{businessname}</h2>
            <BukkaCarousel />
          </section>
          <section className="right right-bukka center mt-25 mb-50">
            <h2 className="center mb-25 mt-25">For Reservations</h2>
            <section className="bukka-reservations">
              <h3 className="bukka-reservations-text bukka-price">Price: From N{price}. </h3>
              <h3 className="bukka-reservations-text">Price depends on food and quantity. </h3>
              <h3 className="bukka-reservations-text"><FaPhoneSquare size="1.2rem" className="bukka-icons mr-10 bukka-color" />Phone: &nbsp;<a href="tel:08139844222" className="phone-email-link">{phone}</a></h3>
              <h3 className="bukka-reservations-text"><MdEmail size="1.2rem" className="bukka-icons mr-10 bukka-color" /><a href="email:ibasira-ng@gmail.com" className="phone-email-link">{email}</a></h3>
            </section>
            <section>
              <iframe
                src={mapLink}
                title="Location on Map"
                width="300"
                height="300"
                frameBorder="0"
                style={{ border: "0" }}
                allowFullScreen=""
                aria-hidden="false"
                tabIndex="0"
              ></iframe>
            </section>
          </section>
          <section className="clear bukka-details">
          <h2 className="text-left mb-25 mt-25">Restaurants Details</h2>
          <section restaurant-details-container>
            <ul className="restaurant-details-item text-left mb-25">
              <li className="restaurant-list-details">
                <b><FaPhoneSquare size="1.2rem" className="bukka-icons mr-10 bukka-color" />{phone}&nbsp;</b><a href="tel:08139844222" className="phone-email-link">08139844222</a>
              </li>
              <li className="restaurant-list-details">
                <b><MdEmail size="1.2rem" className="bukka-icons mr-10 bukka-color" />{email}:</b> &nbsp;<a href="email:ibasira-ng@gmail.com" className="phone-email-link">ibasira-ng@gmail.com</a>
              </li>
              <li className="restaurant-list-details">
                <b><FcRating size="1.2rem" className="bukka-icons mr-10 bukka-color" />Reviews & Rating:&nbsp;</b> {rating} ({reviews} reviews)
              </li>
              <li className="restaurant-list-details">
                <b><MdLocationOn size="1.2rem" className="bukka-icons mr-10 bukka-color" />Location:&nbsp;</b> {location}
              </li>
              <li className="restaurant-list-details">
                <b><IoMdRestaurant size="1.2rem" className="bukka-icons mr-10 bukka-color" />Restaurant Type:&nbsp;</b>{restaurantType}
              </li>
              <li className="restaurant-list-details">
                <b><FaMoneyBill size="1.2rem" className="bukka-icons mr-10 bukka-color" />Cost:&nbsp;</b> From N{price}
              </li>
            </ul>

            <ul className="restaurant-details-item text-left mb-25">
              <li className="restaurant-list-details">
                <b><FaChair size="1.2rem" className="bukka-icons mr-10 bukka-color" />Capacity&nbsp;</b> {capacity} tables
              </li>
              <li className="restaurant-list-details">
                <b><IoIosTime size="1.2rem" className="bukka-icons mr-10 bukka-color" />Hours of operation&nbsp;</b> <br />
                Mon–Fri: {hoursWeekday} <br /> Sat {hoursSat} <br /> Sun:
                {hoursSun}
              </li>
              <li className="restaurant-list-details">
                <b><FaCar size="1.2rem" className="bukka-icons mr-10 bukka-color" />Parking?&nbsp;</b> {parking}
              </li>
              <li className="restaurant-list-details">
                <b><FaRestroom size="1.2rem" className="bukka-icons mr-10 bukka-color" />Restroom?&nbsp;</b> {restroom}
              </li>
            </ul>
            </section>
            <p>
              <b>Details</b>:<br />
              {details}
              <br />
              <b>Menu</b>: <br />
              {menu}
            </p>
          </section>
        </section>
        <section className="bottom-bukka mt-50">
          <h2 className="text-danger center mb-25">Nearby Restaurants</h2>
          {/* <section className="bukka-card-container">
            <BukkaCards />
            
          </section> */}
        </section>
      </main>
      <Footer />
    </>
  );
};

export default Bukkas;
